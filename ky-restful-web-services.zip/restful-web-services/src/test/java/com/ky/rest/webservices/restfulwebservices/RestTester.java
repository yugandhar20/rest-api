package com.ky.rest.webservices.restfulwebservices;

public class RestTester {

}
