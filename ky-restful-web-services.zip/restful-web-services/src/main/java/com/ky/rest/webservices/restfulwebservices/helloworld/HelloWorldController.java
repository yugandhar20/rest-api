package com.ky.rest.webservices.restfulwebservices.helloworld;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//controller
@RestController
public class HelloWorldController {
	
	//method - Hello World
	//GET
	//URI /hellow-world
	//method
	
	
	@RequestMapping(method=RequestMethod.GET, path = "/hello-world")
	public String helloWorld(){
		
		return "Hello World";
	}
	
	@GetMapping(path="/hello-world-bean")
	public HelloWorldBean helloWorldBean(){
	return new HelloWorldBean("Hello Bean");
	
	}
//hello-world/path-variable/in28Minutes
	@GetMapping(path="/hello-world/path-variable/{name}")
	public HelloWorldBean helloWorldPathVariable(@PathVariable String name){
	return new HelloWorldBean(String.format("Hello Bean,%s",name));
	
	}
}

