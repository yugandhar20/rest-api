package com.citi.pivotal.CitiPivotalAutomation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CitiPivotalAutomationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CitiPivotalAutomationApplication.class, args);
	}
}
